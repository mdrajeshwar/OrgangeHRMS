﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestProject3.PageObjects
{
    public class HomePage : BasePage
    {
        public IWebElement UserNameLabel
        {
            get
            {
                return _driver.FindElement(By.XPath("//p[@class='oxd-text oxd-text--p'][1]"));
            }
        }

        public IWebElement PasswordLabel
        {
            get
            {
                return _driver.FindElement(By.XPath("//p[@class='oxd-text oxd-text--p'][2]"));
            }
        }

        public IWebElement UserNameInput
        {
            get
            {
                return _driver.FindElement(By.XPath("//input[@name='username']"));
            }
        }

        public IWebElement PasswordInput
        {
            get
            {
                return _driver.FindElement(By.XPath("//input[@name='password']"));
            }
        }

        public IWebElement LoginButton
        {
            get
            {
                return _driver.FindElement(By.XPath("//button[@type='submit']"));
            }
        }

        //dynamic
        public string GetUserName()
        {
            var username = UserNameLabel.Text.Split(":")[1].Trim();
            return username;
        }

        public string GetPassword()
        {
            var password = PasswordLabel.Text.Split(":")[1].Trim();
            return password;
        }

        public void SetUserName(string userName)
        {
            UserNameInput.SendKeys(userName);
        }

        public void SetPassword(string password)
        {
            PasswordInput.SendKeys(password);
        }

        public void ClickLoginButton()
        {
            LoginButton.Click();
        }
    }
}
