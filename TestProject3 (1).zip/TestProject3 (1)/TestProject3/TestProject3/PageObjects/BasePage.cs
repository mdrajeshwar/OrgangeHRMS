﻿using OpenQA.Selenium;
using TestProject3.Utilities;

namespace TestProject3.PageObjects
{
    public class BasePage
    {
        internal static IWebDriver _driver;

        public BasePage()
        {
            if (_driver == null)
                _driver = BrowserFactory.LaunchBrowser(BrowserType.CHROME);
        }


        public IWebElement AdminTab
        {
            get
            {
                return _driver.FindElement(By.XPath("//span[text()='Admin']"));
            }
        }


        public bool NavigateToUrl(string urlToNavigate)
        {
            _driver.Navigate().GoToUrl(urlToNavigate);

            if (_driver.Url == urlToNavigate)
                return true;
            else
                return false;
        }

        public void NavigateToTab(NavigationTabs navigationTab)
        {
            switch (navigationTab)
            {
                case NavigationTabs.Admin:
                    AdminTab.Click();
                    break;
            }
        }

        public void MaximizeWindow()
        {
            _driver.Manage().Window.Maximize();
        }

        public void TearDown()
        {
            _driver.Quit();
        }
    }

    public enum NavigationTabs
    {
        Admin
    }
}
