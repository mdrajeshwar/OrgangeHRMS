﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestProject3.Utilities;

namespace TestProject3.PageObjects
{
    public class Controller
    {
        public AdminPage AdminPage
        {
            get
            {
                return new AdminPage();
            }
        }

        public HomePage HomePage
        {
            get
            {
                return new HomePage();
            }
        }
      
        
    }
}
