﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestProject3.Utilities;

namespace TestProject3.PageObjects
{
    public class AdminPage : BasePage
    {
        public IWebElement EditUserMarkerButton
        {
            get
            {
                return _driver.FindElement(By.XPath("(//i[@class='oxd-icon bi-pencil-fill'])[2]"));
            }
        }
        public IWebElement UserRole
        {
            get
            {
                String UserRoleS = "//label[contains(., 'User Role')]//following::div[1]//div[@class='oxd-select-text-input']";
                return _driver.FindElement(By.XPath(UserRoleS));
            }
        }
        public IWebElement SaveUserRole
        {
            get
            {
                String SaveUserRole = "//button[@type='submit']";
                return _driver.FindElement(By.XPath(SaveUserRole));
            }
        }
        public IWebElement SelectOptionEle
        {
            get
            {
                String SelectOpt = "//*[@role='listbox']//div[not(contains(@class, 'oxd-select-option --'))]";
                return _driver.FindElement(By.XPath(SelectOpt));
            }
        }


        public void ToggleUser()
        {
          //  String UserRoleS = "//label[contains(., 'User Role')]//following::div[1]//div[@class='oxd-select-text-input']";
            //IWebElement UserRole = _driver.FindElement(By.XPath(UserRoleS));
            UserRole.Click();
            Thread.Sleep(3000);
            var se = _driver.FindElements(By.XPath("//*[@role='listbox']//div[not(contains(@class, 'oxd-select-option --'))]"));
            // Thread.Sleep(5000);

            foreach (var item in se)
            {
                Console.WriteLine(item.Text);
                if (item.Text != "-- Select --")
                {
                    item.Click();

                    Thread.Sleep(5000);
                    SaveUserRole.Click();
                    Thread.Sleep(8000);

                }
                else
                {
                    Console.WriteLine(item.Text);
                }

            }
            try
            {
                NavigateToTab(NavigationTabs.Admin);

            }
            catch (Exception)
            {

                throw;
            }
            Thread.Sleep(5000);

            GeneralUtilities.takeScreenshotAfterChange();
        }

        public void ClickEditMarkerButton()
        {
            EditUserMarkerButton.Click();
        }
    }
}
