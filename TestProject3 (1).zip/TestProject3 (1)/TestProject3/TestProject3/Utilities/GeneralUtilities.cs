﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestProject3.PageObjects;

namespace TestProject3.Utilities
{
    public class GeneralUtilities :BasePage
    {
        public static void takeScreenshotBeforeChange()
        {

            Screenshot ss = ((ITakesScreenshot)_driver).GetScreenshot();
            String dateTimenow = DateTime.Now.ToString("yyyyMMdd-HHmmss");
            String FileName = "BeforeChange " + dateTimenow + ".png";
            ss.SaveAsFile(FileName);

        }
        public static void takeScreenshotAfterChange()
        {

            Screenshot ss = ((ITakesScreenshot)_driver).GetScreenshot();
            String dateTimenow = DateTime.Now.ToString("yyyyMMdd-HHmmss");
            String FileName = "AfterChange " + dateTimenow + ".png";
            ss.SaveAsFile(FileName);

        }

    }
    
}
