﻿using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Edge;

namespace TestProject3.Utilities
{
    public class BrowserFactory
    {
        public static IWebDriver LaunchBrowser(BrowserType browserType)
        {
            IWebDriver driver = null;
            switch (browserType)
            {
                case BrowserType.CHROME:
                    driver = new ChromeDriver();
                    break;
                case BrowserType.EDGE:
                    driver = new EdgeDriver();
                    break;
            }
            return driver;
        }
    }

    public enum BrowserType
    {
        CHROME,
        EDGE
    }
}
