using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.DevTools.V125.SystemInfo;
using TestProject3.PageObjects;
using TestProject3.Utilities;

namespace TestProject3.Tests
{
    public class HomePageTests
    {


        [Test]
        public void ToggleUserTest()
        {
            Controller controller = new Controller();
            try
            {
                controller.HomePage.NavigateToUrl("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
                controller.HomePage.MaximizeWindow();

                Thread.Sleep(1000);
                string userName = controller.HomePage.GetUserName();
                string password = controller.HomePage.GetPassword();


                Thread.Sleep(1000);
                // Set username and passwork, click on login
                controller.HomePage.SetUserName(userName);
                controller.HomePage.SetPassword(password);
                controller.HomePage.ClickLoginButton();

                Thread.Sleep(5000);
                // Navigate to Admin tab
                controller.HomePage.NavigateToTab(NavigationTabs.Admin);
                // SS before changing the value
                Thread.Sleep(2000);
                GeneralUtilities.takeScreenshotBeforeChange();

                Thread.Sleep(2000);

                controller.AdminPage.ClickEditMarkerButton();
                Thread.Sleep(3000);
                // Toggling the user 

                controller.AdminPage.ToggleUser();
                Thread.Sleep(2000);
                controller.HomePage.TearDown();
            }
            catch (Exception ex)
            {
                controller.HomePage.TearDown();
                throw;
            }

        }

    }

}